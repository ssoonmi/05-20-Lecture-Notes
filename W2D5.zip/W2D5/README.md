# W2D5 Notes

## Morning Notes on Context
- [morning_notes.js]

## Evening Notes on Context
- [context.js]

## Learning Objectives not filled out
- [empty_learning_objectives.js]

## Assessment 2 Prep
- [Assessment 2 Prep material]
- [Assessment 2 Prep material download]


[morning_notes.js]: ./morning_notes.js
[empty_learning_objectives.js]: ../assessment2Prep/empty_learning_objectives.js
[context.js]: ./context.js
[Assessment 2 Prep material]: ../assessment2Prep
[Assessment 2 Prep material download]: ../assessment2Prep.zip