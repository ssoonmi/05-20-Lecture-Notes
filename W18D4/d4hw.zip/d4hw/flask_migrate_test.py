# flask_migrate_test.py
from app import app