// Nested Loops
for (let i = 0; i < 2; i++) {
  // console.log(i);
  for (let j = 0; j < 3; j++) {
    // console.log('    ', j);

    console.log(i, j);
  }
}