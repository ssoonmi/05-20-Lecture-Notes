# Assessment 2 Prep

## [Day 1 Learning Objectives]

## [Day 2 Learning Objectives]

## [Day 3 Learning Objectives]

## [Day 4 Learning Objectives]

## [Day 5 Learning Objectives]

## [Empty Learning Objectives]

## [Creating a new folder in VSCode]

## [Mutability && Primitive && Reference Examples]

## [Returning a Function in a Function Demo]

[Day 1 Learning Objectives]: ./d1.md
[Day 2 Learning Objectives]: ./d2.md
[Day 3 Learning Objectives]: ./d3.md
[Day 4 Learning Objectives]: ./d4.md
[Day 5 Learning Objectives]: ./d5.md
[Creating a new folder in VSCode]: ./add_folder.png
[Empty Learning Objectives]: ./empty_learning_objectives.js
[Mutability && Primitive && Reference Examples]: ./mutability.md
[Returning a Function in a Function Demo]: ./returningFunctionDemo.js