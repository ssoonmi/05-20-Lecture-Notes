INSERT INTO countries (name, continent_name)
VALUES
('Brazil', 'South America'),
('China', 'Asia'),
('USA', 'North America')
